export class Empleado {
    nombre : string;
    salario: number;

    constructor (pNombre, pSalario) { 
        this.nombre = pNombre;
        this.salario = pSalario;
    }
}


