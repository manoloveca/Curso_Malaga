import { hello } from "./modulo.js";  
var app = {  
    foo: () => {
        hello("Carlos");
    }
}
