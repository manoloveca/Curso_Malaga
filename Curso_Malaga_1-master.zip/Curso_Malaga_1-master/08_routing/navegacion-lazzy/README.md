# HolaModulos #

Ejemplo de la modificación de un proyecto creado inicialmente con ng new
añadiendo un **modolo para elementos compartidos**, que incluye los componentes **cabecera** y **pie**.

Se han añadido estilos css tanto generales, para la aplicación, como a nivel de todos los componentes.

Incorpora dos componentes "formulario" en los que puede verse el **doble binding** empleando dos formatos diferentes

- el más explicito, en el que se utiliza ***ngModel*** y ***ngModelChanges***

- el más sencillo, que utiliza la notación conocida como ***babnana in a box***

Nota:

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 1.4.1.
