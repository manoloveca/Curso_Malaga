export class Provincia {
    // idProvincia: number;
    nombre: string;

    constructor(public idProvincia: number, nombre) {
        this.nombre = nombre;
    }
}
