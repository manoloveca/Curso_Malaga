# Formularios

Ejemplo de formulario que utiliza los controles más habituales:

- Radio-butons

- CHeckBox

- Select / options

Este último se crea dinámicamente a partir de una array de objetos, cada uno de los cuales incluye un identificador y el nombre de una provincia

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 1.4.1.

