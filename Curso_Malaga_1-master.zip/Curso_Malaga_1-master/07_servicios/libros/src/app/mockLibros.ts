export const LIBROS = [
    'Angular para Expertos',
    'Aprende Angular 4',
    'Angular Avanzado'
];
