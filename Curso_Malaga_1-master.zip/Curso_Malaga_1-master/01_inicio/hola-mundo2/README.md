# HolaMundo2 #

Ejercicios iniciales del curso.

Corresponde al resultado de la instrucción ***ng new hola-mundo*** para generar un proyecto inicial con sus correspondientes **módulo raíz** y **componente inicial**, en el que este último ha sido levemente modificado, cambiando el texto y la imagen que muestra.

Nota:

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 1.4.1.
