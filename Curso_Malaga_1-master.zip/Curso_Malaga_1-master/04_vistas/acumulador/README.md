# Acumulador

Ejemplo de uso de clases CSS a partir de las directivas de Angular

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 1.4.1.
