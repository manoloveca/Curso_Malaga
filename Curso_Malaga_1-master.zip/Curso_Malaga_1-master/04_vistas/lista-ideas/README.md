# HolaModulos #

Ejemplo de la modificación de un proyecto creado inicialmente con ng new
añadiendo un **modolo para elementos compartidos**, que incluye los componentes **cabecera** y **pie**.

Se han añadido estilos css tanto generales, para la aplicación, como a nivel de todos los componentes.

Se incluye un componente capaz de recoger "ideas" del usuario y mostrarlas como una lista, construyendo para ello un array que luego es iterado gracias a la directiva ***\*ngFor***

Nota:

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 1.4.1.
