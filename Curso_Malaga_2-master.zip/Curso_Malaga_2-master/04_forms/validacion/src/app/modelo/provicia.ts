export class Provincia {
    id: string;
    name: string;
}