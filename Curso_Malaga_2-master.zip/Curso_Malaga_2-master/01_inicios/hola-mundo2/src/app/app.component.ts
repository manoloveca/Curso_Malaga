import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  curso = 'Angular 4.x';
  formador = 'Alejandro Cerezo Lasne';
  empresa = 'Icono Training Consulting';
  fecha = '2017';
}
