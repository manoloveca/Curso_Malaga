import {Empleado} from './empleado';

class ListaEmpleados {
    aEmpleados : Array<Empleado>;
}