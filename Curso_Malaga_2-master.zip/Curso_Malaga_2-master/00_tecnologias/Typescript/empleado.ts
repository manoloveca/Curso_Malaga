export class Empleado {
//	nombre : string;
//	salario: number;
    
//	constructor (pNombre, pSalario) { 
//		this.nombre = pNombre;
//		this.salario = pSalario;
//	}

    constructor(public nombre: string, 
                public salario: number) {}
}